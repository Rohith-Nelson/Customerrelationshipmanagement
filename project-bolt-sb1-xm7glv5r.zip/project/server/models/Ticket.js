import mongoose from 'mongoose'

const ticketSchema = new mongoose.Schema({
  subject: {
    type: String,
    required: [true, 'Subject is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Description is required']
  },
  status: {
    type: String,
    enum: ['open', 'in-progress', 'closed', 'cancelled'],
    default: 'open'
  },
  priority: {
    type: String,
    enum: ['low', 'medium', 'high', 'urgent'],
    default: 'medium'
  },
  client: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Client',
    required: true
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Manager',
    default: null
  },
  notes: {
    type: String,
    default: ''
  }
}, { timestamps: true })

// Index for improved query performance
ticketSchema.index({ client: 1, status: 1 })
ticketSchema.index({ assignedTo: 1, status: 1 })
ticketSchema.index({ priority: 1, status: 1 })

const Ticket = mongoose.model('Ticket', ticketSchema)

export default Ticket
import mongoose from 'mongoose'

const interactionSchema = new mongoose.Schema({
  ticket: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Ticket',
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    refPath: 'userType', // Dynamic ref based on userType
    required: true
  },
  userType: {
    type: String,
    enum: ['Client', 'Manager'],
    required: true
  },
  message: {
    type: String,
    required: true
  },
  attachments: [{
    name: String,
    url: String,
    type: String
  }]
}, { timestamps: true })

// Index for improved query performance
interactionSchema.index({ ticket: 1, createdAt: 1 })

const Interaction = mongoose.model('Interaction', interactionSchema)

export default Interaction
import jwt from 'jsonwebtoken'
import Client from '../models/Client.js'
import Manager from '../models/Manager.js'

// Protect routes that require authentication
export const protect = async (req, res, next) => {
  try {
    let token
    
    // Check for token in Authorization header
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1]
    }
    
    if (!token) {
      return res.status(401).json({ message: 'Not authorized, no token' })
    }
    
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key')
    
    // Check if user exists
    let user
    if (decoded.role === 'client') {
      user = await Client.findById(decoded.id)
    } else if (decoded.role === 'manager') {
      user = await Manager.findById(decoded.id)
    }
    
    if (!user) {
      return res.status(401).json({ message: 'User not found' })
    }
    
    // Add user and role to request
    req.user = user
    req.role = decoded.role
    next()
  } catch (error) {
    console.error('Auth middleware error:', error)
    return res.status(401).json({ message: 'Not authorized, token failed' })
  }
}

// Restrict to specific roles
export const authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.role)) {
      return res.status(403).json({ 
        message: `Access denied. Role '${req.role}' not authorized.` 
      })
    }
    next()
  }
}
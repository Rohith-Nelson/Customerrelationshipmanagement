import express from 'express'
import {
  getClientProfile,
  updateClientProfile,
  createTicket,
  getClientTickets
} from '../controllers/clientController.js'
import { protect, authorize } from '../middleware/auth.js'

const router = express.Router()

// Protect all routes
router.use(protect)
router.use(authorize('client'))

// Profile routes
router.get('/profile', getClientProfile)
router.put('/profile', updateClientProfile)

// Ticket routes
router.post('/ticket', createTicket)
router.get('/tickets', getClientTickets)

export default router
import express from 'express'
import {
  registerClient,
  loginClient,
  registerManager,
  loginManager
} from '../controllers/authController.js'

const router = express.Router()

// Client routes
router.post('/client/register', registerClient)
router.post('/client/login', loginClient)

// Manager routes
router.post('/manager/register', registerManager)
router.post('/manager/login', loginManager)

export default router
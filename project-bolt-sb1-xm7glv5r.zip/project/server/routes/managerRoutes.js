import express from 'express'
import {
  getClients,
  deleteClient,
  getTickets,
  updateTicket
} from '../controllers/managerController.js'
import { protect, authorize } from '../middleware/auth.js'

const router = express.Router()

// Protect all routes
router.use(protect)
router.use(authorize('manager'))

// Client routes
router.get('/clients', getClients)
router.delete('/client/:id', deleteClient)

// Ticket routes
router.get('/tickets', getTickets)
router.put('/tickets/:id', updateTicket)

export default router
import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import mongoose from 'mongoose'
import morgan from 'morgan'

// Load environment variables
dotenv.config()

// Import routes
import authRoutes from './routes/authRoutes.js'
import clientRoutes from './routes/clientRoutes.js'
import managerRoutes from './routes/managerRoutes.js'

// Initialize express app
const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(express.json())
app.use(morgan('dev'))

// Routes
app.use('/api/auth', authRoutes)
app.use('/api/client', clientRoutes)
app.use('/api/manager', managerRoutes)

// Root route
app.get('/', (req, res) => {
  res.send('CRM API is running')
})

// Connect to MongoDB and start server
const startServer = async () => {
  try {
    // Use local MongoDB for development
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/crm_system')
    console.log('Connected to MongoDB')
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`)
    })
  } catch (error) {
    console.error('Failed to connect to MongoDB:', error.message)
    process.exit(1)
  }
}

startServer()
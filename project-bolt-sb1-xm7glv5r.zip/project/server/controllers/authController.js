import jwt from 'jsonwebtoken'
import Client from '../models/Client.js'
import Manager from '../models/Manager.js'

// Generate JWT token
const generateToken = (id, role) => {
  return jwt.sign(
    { id, role }, 
    process.env.JWT_SECRET || 'your-secret-key', 
    { expiresIn: '30d' }
  )
}

// @desc    Register new client
// @route   POST /api/auth/client/register
// @access  Public
export const registerClient = async (req, res) => {
  try {
    const { name, email, password, phone, company } = req.body
    
    // Check if client already exists
    const clientExists = await Client.findOne({ email })
    if (clientExists) {
      return res.status(400).json({ message: 'Client already exists' })
    }
    
    // Create new client
    const client = await Client.create({
      name,
      email,
      password,
      phone,
      company
    })
    
    // Generate token
    const token = generateToken(client._id, 'client')
    
    res.status(201).json({
      token,
      user: {
        _id: client._id,
        name: client.name,
        email: client.email,
        role: 'client'
      }
    })
  } catch (error) {
    console.error('Register client error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}

// @desc    Authenticate client
// @route   POST /api/auth/client/login
// @access  Public
export const loginClient = async (req, res) => {
  try {
    const { email, password } = req.body
    
    // Find client by email
    const client = await Client.findOne({ email }).select('+password')
    if (!client) {
      return res.status(401).json({ message: 'Invalid credentials' })
    }
    
    // Check password
    const isPasswordCorrect = await client.comparePassword(password)
    if (!isPasswordCorrect) {
      return res.status(401).json({ message: 'Invalid credentials' })
    }
    
    // Generate token
    const token = generateToken(client._id, 'client')
    
    res.json({
      token,
      user: {
        _id: client._id,
        name: client.name,
        email: client.email,
        role: 'client'
      }
    })
  } catch (error) {
    console.error('Login client error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}

// @desc    Register new manager
// @route   POST /api/auth/manager/register
// @access  Public
export const registerManager = async (req, res) => {
  try {
    const { name, email, password, department, position } = req.body
    
    // Check if manager already exists
    const managerExists = await Manager.findOne({ email })
    if (managerExists) {
      return res.status(400).json({ message: 'Manager already exists' })
    }
    
    // Create new manager
    const manager = await Manager.create({
      name,
      email,
      password,
      department,
      position
    })
    
    // Generate token
    const token = generateToken(manager._id, 'manager')
    
    res.status(201).json({
      token,
      user: {
        _id: manager._id,
        name: manager.name,
        email: manager.email,
        role: 'manager'
      }
    })
  } catch (error) {
    console.error('Register manager error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}

// @desc    Authenticate manager
// @route   POST /api/auth/manager/login
// @access  Public
export const loginManager = async (req, res) => {
  try {
    const { email, password } = req.body
    
    // Find manager by email
    const manager = await Manager.findOne({ email }).select('+password')
    if (!manager) {
      return res.status(401).json({ message: 'Invalid credentials' })
    }
    
    // Check password
    const isPasswordCorrect = await manager.comparePassword(password)
    if (!isPasswordCorrect) {
      return res.status(401).json({ message: 'Invalid credentials' })
    }
    
    // Generate token
    const token = generateToken(manager._id, 'manager')
    
    res.json({
      token,
      user: {
        _id: manager._id,
        name: manager.name,
        email: manager.email,
        role: 'manager'
      }
    })
  } catch (error) {
    console.error('Login manager error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}
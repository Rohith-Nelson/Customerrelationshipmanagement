import Client from '../models/Client.js'
import Ticket from '../models/Ticket.js'
import Manager from '../models/Manager.js'

// @desc    Get all clients
// @route   GET /api/manager/clients
// @access  Private (Manager only)
export const getClients = async (req, res) => {
  try {
    const clients = await Client.find().select('-__v')
    
    // Add active tickets count for each client
    const clientsWithTickets = await Promise.all(clients.map(async (client) => {
      const activeTickets = await Ticket.countDocuments({
        client: client._id,
        status: { $in: ['open', 'in-progress'] }
      })
      
      return {
        ...client.toObject(),
        activeTickets
      }
    }))
    
    res.json({ clients: clientsWithTickets })
  } catch (error) {
    console.error('Get clients error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}

// @desc    Delete client
// @route   DELETE /api/manager/client/:id
// @access  Private (Manager only)
export const deleteClient = async (req, res) => {
  try {
    const client = await Client.findById(req.params.id)
    
    if (!client) {
      return res.status(404).json({ message: 'Client not found' })
    }
    
    // Delete client's tickets
    await Ticket.deleteMany({ client: req.params.id })
    
    // Delete client
    await client.deleteOne()
    
    res.json({ message: 'Client and all associated data removed' })
  } catch (error) {
    console.error('Delete client error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}

// @desc    Get all tickets
// @route   GET /api/manager/tickets
// @access  Private (Manager only)
export const getTickets = async (req, res) => {
  try {
    const tickets = await Ticket.find()
      .sort({ updatedAt: -1 })
      .populate('client', 'name email company')
      .populate('assignedTo', 'name email')
    
    res.json({ tickets })
  } catch (error) {
    console.error('Get tickets error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}

// @desc    Update ticket
// @route   PUT /api/manager/tickets/:id
// @access  Private (Manager only)
export const updateTicket = async (req, res) => {
  try {
    const { status, assignedTo, notes } = req.body
    
    // Validate ticket exists
    const ticket = await Ticket.findById(req.params.id)
    if (!ticket) {
      return res.status(404).json({ message: 'Ticket not found' })
    }
    
    // Validate manager exists if assignedTo is provided
    if (assignedTo) {
      const manager = await Manager.findById(assignedTo)
      if (!manager) {
        return res.status(400).json({ message: 'Assigned manager not found' })
      }
    }
    
    // Update ticket
    const updatedTicket = await Ticket.findByIdAndUpdate(
      req.params.id,
      {
        status: status || ticket.status,
        assignedTo: assignedTo || ticket.assignedTo,
        notes: notes || ticket.notes
      },
      { new: true, runValidators: true }
    )
      .populate('client', 'name email company')
      .populate('assignedTo', 'name email')
    
    res.json({ ticket: updatedTicket })
  } catch (error) {
    console.error('Update ticket error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}
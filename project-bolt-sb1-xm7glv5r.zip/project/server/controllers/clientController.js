import Client from '../models/Client.js'
import Ticket from '../models/Ticket.js'

// @desc    Get client profile
// @route   GET /api/client/profile
// @access  Private (Client only)
export const getClientProfile = async (req, res) => {
  try {
    const client = await Client.findById(req.user._id)
    
    if (!client) {
      return res.status(404).json({ message: 'Client not found' })
    }
    
    res.json({ client })
  } catch (error) {
    console.error('Get client profile error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}

// @desc    Update client profile
// @route   PUT /api/client/profile
// @access  Private (Client only)
export const updateClientProfile = async (req, res) => {
  try {
    const { name, phone, company, address } = req.body
    
    // Find and update client
    const client = await Client.findByIdAndUpdate(
      req.user._id,
      {
        name,
        phone,
        company,
        address,
        profileCompleted: true
      },
      { new: true, runValidators: true }
    )
    
    if (!client) {
      return res.status(404).json({ message: 'Client not found' })
    }
    
    res.json({ client })
  } catch (error) {
    console.error('Update client profile error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}

// @desc    Create new ticket
// @route   POST /api/client/ticket
// @access  Private (Client only)
export const createTicket = async (req, res) => {
  try {
    const { subject, description, priority } = req.body
    
    // Create ticket
    const ticket = await Ticket.create({
      subject,
      description,
      priority: priority || 'medium',
      client: req.user._id
    })
    
    res.status(201).json({ ticket })
  } catch (error) {
    console.error('Create ticket error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}

// @desc    Get client tickets
// @route   GET /api/client/tickets
// @access  Private (Client only)
export const getClientTickets = async (req, res) => {
  try {
    const tickets = await Ticket.find({ client: req.user._id })
      .sort({ updatedAt: -1 })
      .populate('assignedTo', 'name email')
    
    res.json({ tickets })
  } catch (error) {
    console.error('Get client tickets error:', error)
    res.status(500).json({ message: 'Server error', error: error.message })
  }
}
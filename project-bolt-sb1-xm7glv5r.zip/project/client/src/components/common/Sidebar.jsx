import { Link, useLocation } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { 
  FiHome, FiUser, FiFileText, FiUsers, FiSettings, FiChevronLeft, FiChevronRight 
} from 'react-icons/fi'

const Sidebar = () => {
  const { user } = useAuth()
  const location = useLocation()
  const [collapsed, setCollapsed] = useState(false)
  
  const isClient = user?.role === 'client'
  const currentPath = location.pathname
  
  const toggleSidebar = () => {
    setCollapsed(!collapsed)
  }
  
  const clientLinks = [
    { path: '/client/dashboard', name: 'Dashboard', icon: <FiHome /> },
    { path: '/client/profile', name: 'My Profile', icon: <FiUser /> },
    { path: '/client/tickets', name: 'Support Tickets', icon: <FiFileText /> },
  ]
  
  const managerLinks = [
    { path: '/manager/dashboard', name: 'Dashboard', icon: <FiHome /> },
    { path: '/manager/clients', name: 'Manage Clients', icon: <FiUsers /> },
    { path: '/manager/tickets', name: 'Manage Tickets', icon: <FiFileText /> },
  ]
  
  const links = isClient ? clientLinks : managerLinks
  
  return (
    <aside 
      className={`fixed left-0 top-16 bottom-0 bg-white border-r border-[var(--border)] transition-all duration-300 z-20 shadow-sm
                 ${collapsed ? 'w-20' : 'w-64'} hidden md:block`}
    >
      <div className="p-4 h-full flex flex-col">
        <div className="flex items-center justify-between mb-6">
          {!collapsed && <h2 className="text-lg font-semibold">{isClient ? 'Client Area' : 'Manager Area'}</h2>}
          <button 
            onClick={toggleSidebar}
            className="p-2 rounded-full hover:bg-gray-100 text-[var(--text-secondary)]"
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <FiChevronRight /> : <FiChevronLeft />}
          </button>
        </div>
        
        <nav className="flex-1">
          <ul className="space-y-2">
            {links.map((link) => (
              <li key={link.path}>
                <Link
                  to={link.path}
                  className={`flex items-center py-2 px-4 rounded-md transition-colors duration-200
                            ${currentPath === link.path 
                              ? 'bg-blue-50 text-[var(--primary)]' 
                              : 'text-[var(--text)] hover:bg-gray-50'}`}
                >
                  <span className="text-xl">{link.icon}</span>
                  {!collapsed && <span className="ml-3">{link.name}</span>}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="pt-6 mt-6 border-t border-[var(--border)]">
          <Link
            to="/settings"
            className="flex items-center py-2 px-4 rounded-md text-[var(--text)] hover:bg-gray-50 transition-colors duration-200"
          >
            <span className="text-xl"><FiSettings /></span>
            {!collapsed && <span className="ml-3">Settings</span>}
          </Link>
        </div>
      </div>
    </aside>
  )
}

export default Sidebar
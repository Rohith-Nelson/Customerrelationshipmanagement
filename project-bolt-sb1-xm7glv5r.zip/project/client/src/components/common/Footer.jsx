import { Link } from 'react-router-dom'

const Footer = () => {
  const currentYear = new Date().getFullYear()
  
  return (
    <footer className="bg-white border-t border-[var(--border)] py-6">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <Link to="/" className="text-xl font-bold text-[var(--primary)]">
              CRM System
            </Link>
            <p className="text-sm text-[var(--text-secondary)] mt-1">
              Simplifying customer relationship management
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row sm:space-x-8">
            <div className="mb-4 sm:mb-0">
              <h3 className="text-sm font-semibold uppercase text-[var(--text)] mb-2">Resources</h3>
              <ul className="space-y-2">
                <li>
                  <Link to="/" className="text-sm text-[var(--text-secondary)] hover:text-[var(--primary)]">
                    Documentation
                  </Link>
                </li>
                <li>
                  <Link to="/" className="text-sm text-[var(--text-secondary)] hover:text-[var(--primary)]">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link to="/" className="text-sm text-[var(--text-secondary)] hover:text-[var(--primary)]">
                    Pricing
                  </Link>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-sm font-semibold uppercase text-[var(--text)] mb-2">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <Link to="/" className="text-sm text-[var(--text-secondary)] hover:text-[var(--primary)]">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link to="/" className="text-sm text-[var(--text-secondary)] hover:text-[var(--primary)]">
                    Terms of Service
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="border-t border-[var(--border)] mt-6 pt-6 text-center">
          <p className="text-sm text-[var(--text-secondary)]">
            &copy; {currentYear} CRM System. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
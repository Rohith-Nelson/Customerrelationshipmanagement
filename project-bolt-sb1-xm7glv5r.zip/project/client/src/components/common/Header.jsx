import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../../context/AuthContext'
import { FiMenu, FiX, FiUser, FiLogOut } from 'react-icons/fi'

const Header = () => {
  const { isAuthenticated, user, logout } = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const navigate = useNavigate()

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen)
  }

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <header className="bg-white shadow-sm sticky top-0 z-30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link to="/" className="text-2xl font-bold text-[var(--primary)]">
              CRM System
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-[var(--text-secondary)]">
                  Welcome, {user.name || user.email}
                </span>
                <div className="relative group">
                  <button className="flex items-center text-sm font-medium text-[var(--text)] hover:text-[var(--primary)] transition-colors duration-200">
                    <FiUser className="mr-1" />
                    <span>Account</span>
                  </button>
                  <div className="absolute right-0 w-48 mt-2 origin-top-right bg-white border border-[var(--border)] rounded-md shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                    {user.role === 'client' ? (
                      <Link to="/client/profile" className="block px-4 py-2 text-sm text-[var(--text)] hover:bg-gray-50">
                        My Profile
                      </Link>
                    ) : (
                      <Link to="/manager/dashboard" className="block px-4 py-2 text-sm text-[var(--text)] hover:bg-gray-50">
                        Dashboard
                      </Link>
                    )}
                    <button
                      onClick={handleLogout}
                      className="flex items-center w-full text-left px-4 py-2 text-sm text-[var(--text)] hover:bg-gray-50"
                    >
                      <FiLogOut className="mr-2" /> Logout
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <>
                <Link to="/client/login" className="text-[var(--text)] hover:text-[var(--primary)] transition-colors duration-200">
                  Client Login
                </Link>
                <Link to="/manager/login" className="text-[var(--text)] hover:text-[var(--primary)] transition-colors duration-200">
                  Manager Login
                </Link>
                <Link to="/client/register" className="btn btn-primary">
                  Get Started
                </Link>
              </>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={toggleMobileMenu}
              className="text-[var(--text)] hover:text-[var(--primary)] focus:outline-none"
            >
              {mobileMenuOpen ? <FiX size={24} /> : <FiMenu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-[var(--border)]">
          <div className="container mx-auto px-4 py-3 space-y-3">
            {isAuthenticated ? (
              <>
                <div className="py-2 border-b border-[var(--border)]">
                  <p className="text-sm text-[var(--text-secondary)]">Welcome, {user.name || user.email}</p>
                </div>
                {user.role === 'client' ? (
                  <>
                    <Link
                      to="/client/dashboard"
                      className="block text-[var(--text)] hover:text-[var(--primary)]"
                      onClick={toggleMobileMenu}
                    >
                      Dashboard
                    </Link>
                    <Link
                      to="/client/profile"
                      className="block text-[var(--text)] hover:text-[var(--primary)]"
                      onClick={toggleMobileMenu}
                    >
                      My Profile
                    </Link>
                    <Link
                      to="/client/tickets"
                      className="block text-[var(--text)] hover:text-[var(--primary)]"
                      onClick={toggleMobileMenu}
                    >
                      Support Tickets
                    </Link>
                  </>
                ) : (
                  <>
                    <Link
                      to="/manager/dashboard"
                      className="block text-[var(--text)] hover:text-[var(--primary)]"
                      onClick={toggleMobileMenu}
                    >
                      Dashboard
                    </Link>
                    <Link
                      to="/manager/clients"
                      className="block text-[var(--text)] hover:text-[var(--primary)]"
                      onClick={toggleMobileMenu}
                    >
                      Manage Clients
                    </Link>
                    <Link
                      to="/manager/tickets"
                      className="block text-[var(--text)] hover:text-[var(--primary)]"
                      onClick={toggleMobileMenu}
                    >
                      Manage Tickets
                    </Link>
                  </>
                )}
                <button
                  onClick={() => {
                    handleLogout()
                    toggleMobileMenu()
                  }}
                  className="flex items-center text-[var(--text)] hover:text-[var(--primary)]"
                >
                  <FiLogOut className="mr-2" /> Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/client/login"
                  className="block text-[var(--text)] hover:text-[var(--primary)]"
                  onClick={toggleMobileMenu}
                >
                  Client Login
                </Link>
                <Link
                  to="/manager/login"
                  className="block text-[var(--text)] hover:text-[var(--primary)]"
                  onClick={toggleMobileMenu}
                >
                  Manager Login
                </Link>
                <Link
                  to="/client/register"
                  className="block text-[var(--text)] hover:text-[var(--primary)]"
                  onClick={toggleMobileMenu}
                >
                  Client Register
                </Link>
                <Link
                  to="/manager/register"
                  className="block text-[var(--text)] hover:text-[var(--primary)]"
                  onClick={toggleMobileMenu}
                >
                  Manager Register
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  )
}

export default Header
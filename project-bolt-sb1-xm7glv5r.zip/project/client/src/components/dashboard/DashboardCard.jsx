import { FiArrowUp, FiArrowDown } from 'react-icons/fi'

const DashboardCard = ({ title, value, icon, change, changeType, subtitle }) => {
  const isPositive = changeType === 'positive'
  const isNegative = changeType === 'negative'
  
  return (
    <div className="card hover-scale">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-[var(--text-secondary)] mb-1">{title}</p>
          <h3 className="text-2xl font-bold mb-1">{value}</h3>
          
          {subtitle && <p className="text-xs text-[var(--text-secondary)]">{subtitle}</p>}
          
          {change && (
            <div className="flex items-center mt-2">
              {isPositive && (
                <div className="text-[var(--success)] flex items-center text-sm font-medium">
                  <FiArrowUp className="mr-1" />
                  {change}
                </div>
              )}
              {isNegative && (
                <div className="text-[var(--error)] flex items-center text-sm font-medium">
                  <FiArrowDown className="mr-1" />
                  {change}
                </div>
              )}
              {!isPositive && !isNegative && (
                <div className="text-[var(--text-secondary)] text-sm font-medium">
                  {change}
                </div>
              )}
            </div>
          )}
        </div>
        
        {icon && (
          <div className="rounded-full p-3 bg-blue-50 text-[var(--primary)]">
            {icon}
          </div>
        )}
      </div>
    </div>
  )
}

export default DashboardCard
import { useState } from 'react'
import { toast } from 'react-toastify'
import { createTicket } from '../../services/clientService'

const TicketForm = ({ onTicketCreated }) => {
  const [formData, setFormData] = useState({
    subject: '',
    description: '',
    priority: 'medium'
  })
  const [loading, setLoading] = useState(false)
  
  const { subject, description, priority } = formData
  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!subject || !description) {
      toast.error('Please fill in all required fields')
      return
    }
    
    setLoading(true)
    
    try {
      const response = await createTicket(formData)
      toast.success('Support ticket created successfully')
      setFormData({
        subject: '',
        description: '',
        priority: 'medium'
      })
      
      if (onTicketCreated) {
        onTicketCreated(response.ticket)
      }
    } catch (error) {
      const message = error.response?.data?.message || 'Error creating ticket. Please try again.'
      toast.error(message)
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="card mb-6">
      <h2 className="text-xl font-semibold mb-4">Submit New Support Ticket</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="subject" className="form-label">Subject <span className="text-red-500">*</span></label>
          <input
            type="text"
            id="subject"
            name="subject"
            value={subject}
            onChange={handleChange}
            className="form-input"
            placeholder="Brief description of your issue"
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="description" className="form-label">Description <span className="text-red-500">*</span></label>
          <textarea
            id="description"
            name="description"
            value={description}
            onChange={handleChange}
            rows="4"
            className="form-textarea"
            placeholder="Please provide details about your issue"
            required
          ></textarea>
        </div>
        
        <div className="form-group">
          <label htmlFor="priority" className="form-label">Priority</label>
          <select
            id="priority"
            name="priority"
            value={priority}
            onChange={handleChange}
            className="form-select"
          >
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>
        
        <button 
          type="submit" 
          className="btn btn-primary w-full"
          disabled={loading}
        >
          {loading ? 'Submitting...' : 'Submit Ticket'}
        </button>
      </form>
    </div>
  )
}

export default TicketForm
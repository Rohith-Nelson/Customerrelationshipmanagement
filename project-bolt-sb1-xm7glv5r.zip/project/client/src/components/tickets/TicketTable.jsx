import { useState } from 'react'
import { FiEye, FiEdit2, FiTrash2, FiClock, FiCheckCircle, FiXCircle } from 'react-icons/fi'

const TicketTable = ({ tickets, userRole, onViewTicket, onUpdateTicket, onDeleteTicket }) => {
  const [sortField, setSortField] = useState('createdAt')
  const [sortDirection, setSortDirection] = useState('desc')
  
  // Sorting function
  const sortedTickets = [...tickets].sort((a, b) => {
    let aVal = a[sortField]
    let bVal = b[sortField]
    
    // Handle date fields
    if (sortField === 'createdAt' || sortField === 'updatedAt') {
      aVal = new Date(aVal).getTime()
      bVal = new Date(bVal).getTime()
    }
    
    // Handle string comparison
    if (typeof aVal === 'string') {
      if (sortDirection === 'asc') {
        return aVal.localeCompare(bVal)
      } else {
        return bVal.localeCompare(aVal)
      }
    }
    
    // Handle numeric comparison
    if (sortDirection === 'asc') {
      return aVal - bVal
    } else {
      return bVal - aVal
    }
  })
  
  const handleSort = (field) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortDirection('asc')
    }
  }
  
  const getSortIcon = (field) => {
    if (field !== sortField) return null
    return sortDirection === 'asc' ? '↑' : '↓'
  }
  
  const getStatusBadge = (status) => {
    switch (status) {
      case 'open':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <FiClock className="mr-1" />
            Open
          </span>
        )
      case 'in-progress':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <FiClock className="mr-1" />
            In Progress
          </span>
        )
      case 'closed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <FiCheckCircle className="mr-1" />
            Closed
          </span>
        )
      case 'cancelled':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            <FiXCircle className="mr-1" />
            Cancelled
          </span>
        )
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        )
    }
  }
  
  const getPriorityBadge = (priority) => {
    switch (priority) {
      case 'low':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            Low
          </span>
        )
      case 'medium':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            Medium
          </span>
        )
      case 'high':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            High
          </span>
        )
      case 'urgent':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            Urgent
          </span>
        )
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {priority}
          </span>
        )
    }
  }
  
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }
  
  if (tickets.length === 0) {
    return (
      <div className="card p-8 text-center">
        <p className="text-lg text-[var(--text-secondary)]">No tickets found</p>
      </div>
    )
  }
  
  return (
    <div className="overflow-x-auto rounded-lg border border-[var(--border)]">
      <table className="min-w-full divide-y divide-[var(--border)]">
        <thead className="bg-gray-50">
          <tr>
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider cursor-pointer"
              onClick={() => handleSort('subject')}
            >
              Subject {getSortIcon('subject')}
            </th>
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider cursor-pointer"
              onClick={() => handleSort('status')}
            >
              Status {getSortIcon('status')}
            </th>
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider cursor-pointer"
              onClick={() => handleSort('priority')}
            >
              Priority {getSortIcon('priority')}
            </th>
            {userRole === 'manager' && (
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider"
              >
                Client
              </th>
            )}
            <th 
              scope="col" 
              className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider cursor-pointer"
              onClick={() => handleSort('createdAt')}
            >
              Created {getSortIcon('createdAt')}
            </th>
            <th 
              scope="col" 
              className="px-6 py-3 text-right text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider"
            >
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-[var(--border)]">
          {sortedTickets.map((ticket) => (
            <tr key={ticket._id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-[var(--text)]">{ticket.subject}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                {getStatusBadge(ticket.status)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                {getPriorityBadge(ticket.priority)}
              </td>
              {userRole === 'manager' && (
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-[var(--text)]">{ticket.client?.name || 'Unknown'}</div>
                  <div className="text-xs text-[var(--text-secondary)]">{ticket.client?.email || 'No email'}</div>
                </td>
              )}
              <td className="px-6 py-4 whitespace-nowrap text-sm text-[var(--text-secondary)]">
                {formatDate(ticket.createdAt)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                <button
                  onClick={() => onViewTicket(ticket)}
                  className="text-[var(--primary)] hover:text-[var(--primary-dark)] mr-3"
                  aria-label="View ticket"
                >
                  <FiEye size={18} />
                </button>
                {userRole === 'manager' && (
                  <button
                    onClick={() => onUpdateTicket(ticket)}
                    className="text-[var(--secondary)] hover:text-gray-600 mr-3"
                    aria-label="Edit ticket"
                  >
                    <FiEdit2 size={18} />
                  </button>
                )}
                {userRole === 'manager' && (
                  <button
                    onClick={() => onDeleteTicket(ticket._id)}
                    className="text-[var(--error)] hover:text-red-600"
                    aria-label="Delete ticket"
                  >
                    <FiTrash2 size={18} />
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default TicketTable
import { createContext, useContext, useState, useCallback } from 'react'
import { toast } from 'react-toastify'
import { loginClient, registerClient, loginManager, registerManager } from '../services/authService'

const AuthContext = createContext()

export const useAuth = () => useContext(AuthContext)

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loading, setLoading] = useState(false)
  
  // Check if user is already authenticated
  const checkAuth = useCallback(() => {
    const token = localStorage.getItem('token')
    const userData = localStorage.getItem('user')
    
    if (token && userData) {
      setUser(JSON.parse(userData))
      setIsAuthenticated(true)
    }
  }, [])
  
  // Login client
  const loginClientUser = async (credentials) => {
    setLoading(true)
    try {
      const data = await loginClient(credentials)
      handleAuthSuccess(data, 'Welcome back!')
      return true
    } catch (error) {
      handleAuthError(error)
      return false
    } finally {
      setLoading(false)
    }
  }
  
  // Register client
  const registerClientUser = async (userData) => {
    setLoading(true)
    try {
      const data = await registerClient(userData)
      handleAuthSuccess(data, 'Account created successfully!')
      return true
    } catch (error) {
      handleAuthError(error)
      return false
    } finally {
      setLoading(false)
    }
  }
  
  // Login manager
  const loginManagerUser = async (credentials) => {
    setLoading(true)
    try {
      const data = await loginManager(credentials)
      handleAuthSuccess(data, 'Welcome back!')
      return true
    } catch (error) {
      handleAuthError(error)
      return false
    } finally {
      setLoading(false)
    }
  }
  
  // Register manager
  const registerManagerUser = async (userData) => {
    setLoading(true)
    try {
      const data = await registerManager(userData)
      handleAuthSuccess(data, 'Account created successfully!')
      return true
    } catch (error) {
      handleAuthError(error)
      return false
    } finally {
      setLoading(false)
    }
  }
  
  // Logout user
  const logout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    setUser(null)
    setIsAuthenticated(false)
    toast.info('Logged out successfully')
  }
  
  // Handle auth success
  const handleAuthSuccess = (data, message) => {
    const { token, user } = data
    localStorage.setItem('token', token)
    localStorage.setItem('user', JSON.stringify(user))
    setUser(user)
    setIsAuthenticated(true)
    toast.success(message)
  }
  
  // Handle auth error
  const handleAuthError = (error) => {
    const message = error.response?.data?.message || 'Authentication failed. Please try again.'
    toast.error(message)
  }
  
  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated,
      loading,
      checkAuth,
      loginClientUser,
      registerClientUser,
      loginManagerUser,
      registerManagerUser,
      logout
    }}>
      {children}
    </AuthContext.Provider>
  )
}
import { useState, useEffect } from 'react'
import { toast } from 'react-toastify'
import { FiFilter, FiRefreshCw } from 'react-icons/fi'
import { getTickets, updateTicket } from '../../services/managerService'
import TicketTable from '../../components/tickets/TicketTable'

const Tickets = () => {
  const [tickets, setTickets] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({
    status: '',
    priority: '',
  })
  const [selectedTicket, setSelectedTicket] = useState(null)
  const [showUpdateModal, setShowUpdateModal] = useState(false)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [updateForm, setUpdateForm] = useState({
    status: '',
    assignedTo: '',
    notes: ''
  })
  
  useEffect(() => {
    fetchTickets()
  }, [])
  
  const fetchTickets = async () => {
    try {
      setLoading(true)
      const data = await getTickets()
      setTickets(data.tickets)
    } catch (error) {
      toast.error('Failed to fetch tickets. Please try again.')
    } finally {
      setLoading(false)
    }
  }
  
  const handleFilterChange = (e) => {
    const { name, value } = e.target
    setFilters({
      ...filters,
      [name]: value
    })
  }
  
  const resetFilters = () => {
    setFilters({
      status: '',
      priority: '',
    })
  }
  
  const filteredTickets = tickets.filter((ticket) => {
    return (
      (filters.status === '' || ticket.status === filters.status) &&
      (filters.priority === '' || ticket.priority === filters.priority)
    )
  })
  
  const handleViewTicket = (ticket) => {
    setSelectedTicket(ticket)
    setShowDetailsModal(true)
  }
  
  const handleUpdateTicket = (ticket) => {
    setSelectedTicket(ticket)
    setUpdateForm({
      status: ticket.status,
      assignedTo: ticket.assignedTo?._id || '',
      notes: ticket.notes || ''
    })
    setShowUpdateModal(true)
  }
  
  const handleDeleteTicket = (ticketId) => {
    // Handle ticket deletion
    if (confirm('Are you sure you want to delete this ticket?')) {
      // Call API to delete ticket
      // On success:
      setTickets(tickets.filter(ticket => ticket._id !== ticketId))
      toast.success('Ticket deleted successfully')
    }
  }
  
  const handleUpdateFormChange = (e) => {
    const { name, value } = e.target
    setUpdateForm({
      ...updateForm,
      [name]: value
    })
  }
  
  const submitUpdate = async (e) => {
    e.preventDefault()
    
    try {
      const response = await updateTicket(selectedTicket._id, updateForm)
      
      // Update the tickets list with the updated ticket
      setTickets(tickets.map(ticket => 
        ticket._id === selectedTicket._id ? response.ticket : ticket
      ))
      
      toast.success('Ticket updated successfully')
      setShowUpdateModal(false)
    } catch (error) {
      toast.error('Failed to update ticket. Please try again.')
    }
  }
  
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }
  
  return (
    <div className="page-transition">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Manage Tickets</h1>
        <p className="text-[var(--text-secondary)]">
          View, assign, and update support tickets.
        </p>
      </div>
      
      {/* Filters */}
      <div className="card mb-6">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="w-full sm:w-40">
              <label htmlFor="status" className="form-label">Status</label>
              <select
                id="status"
                name="status"
                value={filters.status}
                onChange={handleFilterChange}
                className="form-select"
              >
                <option value="">All Statuses</option>
                <option value="open">Open</option>
                <option value="in-progress">In Progress</option>
                <option value="closed">Closed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
            
            <div className="w-full sm:w-40">
              <label htmlFor="priority" className="form-label">Priority</label>
              <select
                id="priority"
                name="priority"
                value={filters.priority}
                onChange={handleFilterChange}
                className="form-select"
              >
                <option value="">All Priorities</option>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>
          
          <div className="flex gap-2">
            <button 
              onClick={resetFilters}
              className="btn btn-outline flex items-center"
            >
              <FiFilter className="mr-2" />
              Reset Filters
            </button>
            <button 
              onClick={fetchTickets}
              className="btn btn-outline flex items-center"
            >
              <FiRefreshCw className="mr-2" />
              Refresh
            </button>
          </div>
        </div>
      </div>
      
      {/* Tickets Table */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <p>Loading tickets...</p>
        </div>
      ) : (
        <TicketTable 
          tickets={filteredTickets} 
          userRole="manager"
          onViewTicket={handleViewTicket}
          onUpdateTicket={handleUpdateTicket}
          onDeleteTicket={handleDeleteTicket}
        />
      )}
      
      {/* Ticket Update Modal */}
      {showUpdateModal && selectedTicket && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-xl font-bold">Update Ticket</h2>
                <button 
                  onClick={() => setShowUpdateModal(false)}
                  className="text-[var(--text-secondary)] hover:text-[var(--text)]"
                >
                  &times;
                </button>
              </div>
              
              <form onSubmit={submitUpdate}>
                <div className="mb-4">
                  <p className="font-medium">{selectedTicket.subject}</p>
                  <p className="text-sm text-[var(--text-secondary)]">
                    Submitted by {selectedTicket.client?.name || 'Unknown'} on {formatDate(selectedTicket.createdAt)}
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="form-group">
                    <label htmlFor="status" className="form-label">Status</label>
                    <select
                      id="status"
                      name="status"
                      value={updateForm.status}
                      onChange={handleUpdateFormChange}
                      className="form-select"
                    >
                      <option value="open">Open</option>
                      <option value="in-progress">In Progress</option>
                      <option value="closed">Closed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>
                  
                  <div className="form-group">
                    <label htmlFor="assignedTo" className="form-label">Assigned To</label>
                    <select
                      id="assignedTo"
                      name="assignedTo"
                      value={updateForm.assignedTo}
                      onChange={handleUpdateFormChange}
                      className="form-select"
                    >
                      <option value="">Unassigned</option>
                      {/* This would be populated from a list of managers */}
                      <option value="manager1">John Manager</option>
                      <option value="manager2">Jane Manager</option>
                    </select>
                  </div>
                </div>
                
                <div className="form-group">
                  <label htmlFor="notes" className="form-label">Notes (visible to client)</label>
                  <textarea
                    id="notes"
                    name="notes"
                    value={updateForm.notes}
                    onChange={handleUpdateFormChange}
                    rows="4"
                    className="form-textarea"
                    placeholder="Add any notes or updates about this ticket..."
                  ></textarea>
                </div>
                
                <div className="flex justify-end space-x-4 mt-6">
                  <button 
                    type="button"
                    onClick={() => setShowUpdateModal(false)}
                    className="btn btn-outline"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    className="btn btn-primary"
                  >
                    Update Ticket
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
      
      {/* Ticket Detail Modal */}
      {showDetailsModal && selectedTicket && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-xl font-bold">{selectedTicket.subject}</h2>
                <button 
                  onClick={() => setShowDetailsModal(false)}
                  className="text-[var(--text-secondary)] hover:text-[var(--text)]"
                >
                  &times;
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Status</p>
                  <p className="font-medium capitalize">{selectedTicket.status}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Priority</p>
                  <p className="font-medium capitalize">{selectedTicket.priority}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Created</p>
                  <p className="font-medium">{formatDate(selectedTicket.createdAt)}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Last Updated</p>
                  <p className="font-medium">{formatDate(selectedTicket.updatedAt)}</p>
                </div>
              </div>
              
              <div className="mb-6">
                <p className="text-sm text-[var(--text-secondary)] mb-1">Description</p>
                <p className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap">{selectedTicket.description}</p>
              </div>
              
              <div className="mb-6">
                <p className="text-sm text-[var(--text-secondary)] mb-1">Client</p>
                <div className="bg-gray-50 p-4 rounded-md">
                  <p className="font-medium">{selectedTicket.client?.name || 'Unknown'}</p>
                  <p className="text-sm">{selectedTicket.client?.email || 'No email'}</p>
                  {selectedTicket.client?.phone && (
                    <p className="text-sm">{selectedTicket.client.phone}</p>
                  )}
                </div>
              </div>
              
              {selectedTicket.notes && (
                <div className="mb-6">
                  <p className="text-sm text-[var(--text-secondary)] mb-1">Notes</p>
                  <p className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap">{selectedTicket.notes}</p>
                </div>
              )}
              
              {selectedTicket.assignedTo && (
                <div className="mb-6">
                  <p className="text-sm text-[var(--text-secondary)] mb-1">Assigned To</p>
                  <p className="bg-gray-50 p-4 rounded-md">
                    {selectedTicket.assignedTo.name} ({selectedTicket.assignedTo.email})
                  </p>
                </div>
              )}
              
              <div className="flex justify-end space-x-4">
                <button 
                  onClick={() => {
                    setShowDetailsModal(false)
                    handleUpdateTicket(selectedTicket)
                  }} 
                  className="btn btn-primary"
                >
                  Update Ticket
                </button>
                <button 
                  onClick={() => setShowDetailsModal(false)} 
                  className="btn btn-outline"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Tickets
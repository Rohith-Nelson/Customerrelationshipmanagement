import { useState, useEffect } from 'react'
import { toast } from 'react-toastify'
import { FiSearch, FiEdit2, FiTrash2, FiPlus } from 'react-icons/fi'
import { getClients, deleteClient } from '../../services/managerService'

const Clients = () => {
  const [clients, setClients] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [clientToDelete, setClientToDelete] = useState(null)
  
  useEffect(() => {
    fetchClients()
  }, [])
  
  const fetchClients = async () => {
    try {
      setLoading(true)
      const data = await getClients()
      setClients(data.clients)
    } catch (error) {
      toast.error('Failed to fetch clients. Please try again.')
    } finally {
      setLoading(false)
    }
  }
  
  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value)
  }
  
  const filteredClients = clients.filter(client => {
    const searchTermLower = searchTerm.toLowerCase()
    return (
      client.name?.toLowerCase().includes(searchTermLower) ||
      client.email?.toLowerCase().includes(searchTermLower) ||
      client.company?.toLowerCase().includes(searchTermLower) ||
      client.phone?.toLowerCase().includes(searchTermLower)
    )
  })
  
  const confirmDelete = (client) => {
    setClientToDelete(client)
    setShowDeleteConfirm(true)
  }
  
  const handleDeleteClient = async () => {
    if (!clientToDelete) return
    
    try {
      await deleteClient(clientToDelete._id)
      setClients(clients.filter(c => c._id !== clientToDelete._id))
      toast.success('Client deleted successfully')
    } catch (error) {
      toast.error('Failed to delete client. Please try again.')
    } finally {
      setShowDeleteConfirm(false)
      setClientToDelete(null)
    }
  }
  
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString()
  }
  
  return (
    <div className="page-transition">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
        <div className="mb-4 md:mb-0">
          <h1 className="text-2xl font-bold mb-2">Manage Clients</h1>
          <p className="text-[var(--text-secondary)]">
            View, search, and manage client accounts.
          </p>
        </div>
        <button className="btn btn-primary flex items-center">
          <FiPlus className="mr-2" />
          Add Client
        </button>
      </div>
      
      {/* Search */}
      <div className="card mb-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <FiSearch className="text-[var(--text-secondary)]" />
          </div>
          <input
            type="text"
            placeholder="Search by name, email, company..."
            value={searchTerm}
            onChange={handleSearchChange}
            className="form-input pl-10"
          />
        </div>
      </div>
      
      {/* Clients Table */}
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <p>Loading clients...</p>
        </div>
      ) : filteredClients.length === 0 ? (
        <div className="card p-8 text-center">
          <p className="text-lg text-[var(--text-secondary)] mb-4">
            {searchTerm ? 'No clients match your search.' : 'No clients found.'}
          </p>
          <button className="btn btn-primary inline-flex items-center">
            <FiPlus className="mr-2" />
            Add Your First Client
          </button>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-[var(--border)]">
          <table className="min-w-full divide-y divide-[var(--border)]">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                  Client
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                  Contact Info
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                  Company
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                  Member Since
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                  Active Tickets
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-[var(--border)]">
              {filteredClients.map((client) => (
                <tr key={client._id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-[var(--text)]">{client.name}</div>
                    <div className="text-sm text-[var(--text-secondary)]">ID: {client._id}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-[var(--text)]">{client.email}</div>
                    {client.phone && (
                      <div className="text-sm text-[var(--text-secondary)]">{client.phone}</div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-[var(--text)]">{client.company || '-'}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-[var(--text-secondary)]">
                    {formatDate(client.createdAt)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-[var(--text)]">
                    {client.activeTickets || 0}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      className="text-[var(--secondary)] hover:text-gray-600 mr-4"
                      aria-label="Edit client"
                    >
                      <FiEdit2 size={18} />
                    </button>
                    <button
                      onClick={() => confirmDelete(client)}
                      className="text-[var(--error)] hover:text-red-600"
                      aria-label="Delete client"
                    >
                      <FiTrash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6">
              <h3 className="text-lg font-bold mb-4">Confirm Delete</h3>
              <p className="mb-6">
                Are you sure you want to delete client <span className="font-medium">{clientToDelete?.name}</span>? 
                This action cannot be undone and will delete all associated data.
              </p>
              <div className="flex justify-end space-x-4">
                <button 
                  onClick={() => setShowDeleteConfirm(false)}
                  className="btn btn-outline"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleDeleteClient}
                  className="btn bg-red-600 text-white hover:bg-red-700"
                >
                  Delete Client
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Clients
import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { FiUsers, FiFileText, FiAlertCircle, FiCheckCircle } from 'react-icons/fi'
import DashboardCard from '../../components/dashboard/DashboardCard'
import { getClients } from '../../services/managerService'
import { getTickets } from '../../services/managerService'
import { useAuth } from '../../context/AuthContext'

const ManagerDashboard = () => {
  const [clients, setClients] = useState([])
  const [tickets, setTickets] = useState([])
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [clientsData, ticketsData] = await Promise.all([
          getClients(),
          getTickets()
        ])
        
        setClients(clientsData.clients)
        setTickets(ticketsData.tickets)
      } catch (error) {
        console.error('Error fetching dashboard data:', error)
      } finally {
        setLoading(false)
      }
    }
    
    fetchData()
  }, [])
  
  // Calculate stats
  const totalClients = clients.length
  const totalTickets = tickets.length
  const openTickets = tickets.filter(ticket => ticket.status === 'open').length
  const inProgressTickets = tickets.filter(ticket => ticket.status === 'in-progress').length
  const resolvedTickets = tickets.filter(ticket => ticket.status === 'closed').length
  
  // Get high priority tickets
  const highPriorityTickets = tickets.filter(ticket => 
    (ticket.priority === 'high' || ticket.priority === 'urgent') && 
    (ticket.status === 'open' || ticket.status === 'in-progress')
  ).sort((a, b) => {
    // Sort by priority first (urgent > high)
    if (a.priority !== b.priority) {
      return a.priority === 'urgent' ? -1 : 1
    }
    // Then by status (open > in-progress)
    if (a.status !== b.status) {
      return a.status === 'open' ? -1 : 1
    }
    // Finally by date (newest first)
    return new Date(b.createdAt) - new Date(a.createdAt)
  }).slice(0, 5)
  
  // Get recent clients
  const recentClients = [...clients].sort((a, b) => {
    return new Date(b.createdAt) - new Date(a.createdAt)
  }).slice(0, 5)
  
  return (
    <div className="page-transition">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Manager Dashboard</h1>
        <p className="text-[var(--text-secondary)]">
          Welcome back, {user?.name || 'Manager'}. Here's an overview of your CRM system.
        </p>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <DashboardCard
          title="Total Clients"
          value={totalClients}
          icon={<FiUsers size={24} />}
        />
        
        <DashboardCard
          title="Open Tickets"
          value={openTickets}
          icon={<FiFileText size={24} />}
          change={`${Math.round((openTickets / totalTickets) * 100)}%`}
          changeType={openTickets > totalTickets * 0.5 ? 'negative' : 'positive'}
        />
        
        <DashboardCard
          title="In Progress"
          value={inProgressTickets}
          icon={<FiAlertCircle size={24} />}
          change={`${Math.round((inProgressTickets / totalTickets) * 100)}%`}
        />
        
        <DashboardCard
          title="Resolved Tickets"
          value={resolvedTickets}
          icon={<FiCheckCircle size={24} />}
          change={`${Math.round((resolvedTickets / totalTickets) * 100)}%`}
          changeType="positive"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Priority Tickets */}
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">High Priority Tickets</h2>
            <Link to="/manager/tickets" className="text-sm text-[var(--primary)] hover:underline">
              View all
            </Link>
          </div>
          
          {loading ? (
            <p className="text-center py-4 text-[var(--text-secondary)]">Loading tickets...</p>
          ) : highPriorityTickets.length === 0 ? (
            <p className="text-center py-4 text-[var(--text-secondary)]">No high priority tickets at the moment.</p>
          ) : (
            <div className="space-y-3">
              {highPriorityTickets.map(ticket => (
                <Link 
                  key={ticket._id} 
                  to={`/manager/tickets/${ticket._id}`}
                  className="block p-4 border border-[var(--border)] rounded-lg hover:bg-gray-50"
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{ticket.subject}</span>
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                      ${ticket.priority === 'urgent' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>
                      {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[var(--text-secondary)]">
                      {ticket.client?.name || 'Unknown client'}
                    </span>
                    <span className="text-[var(--text-secondary)]">
                      {new Date(ticket.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
        
        {/* Recent Clients */}
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Recently Added Clients</h2>
            <Link to="/manager/clients" className="text-sm text-[var(--primary)] hover:underline">
              View all
            </Link>
          </div>
          
          {loading ? (
            <p className="text-center py-4 text-[var(--text-secondary)]">Loading clients...</p>
          ) : recentClients.length === 0 ? (
            <p className="text-center py-4 text-[var(--text-secondary)]">No clients added yet.</p>
          ) : (
            <div className="space-y-3">
              {recentClients.map(client => (
                <div 
                  key={client._id}
                  className="p-4 border border-[var(--border)] rounded-lg hover:bg-gray-50"
                >
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">{client.name}</span>
                    <span className="text-sm text-[var(--text-secondary)]">
                      {new Date(client.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-[var(--text-secondary)]">{client.email}</span>
                    <span className="text-[var(--text-secondary)]">
                      {client.company || 'No company'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Quick Actions */}
      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Link to="/manager/tickets" className="btn btn-primary text-center">
            Manage Tickets
          </Link>
          <Link to="/manager/clients" className="btn btn-outline text-center">
            Manage Clients
          </Link>
          <Link to="/reports" className="btn btn-outline text-center">
            View Reports
          </Link>
        </div>
      </div>
    </div>
  )
}

export default ManagerDashboard
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

const ManagerRegister = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    passwordConfirm: '',
    department: '',
    position: ''
  })
  const { registerManagerUser, loading } = useAuth()
  const navigate = useNavigate()
  
  const { name, email, password, passwordConfirm, department, position } = formData
  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (password !== passwordConfirm) {
      alert('Passwords do not match')
      return
    }
    
    // Remove passwordConfirm before sending to API
    const registerData = { ...formData }
    delete registerData.passwordConfirm
    
    const success = await registerManagerUser(registerData)
    if (success) {
      navigate('/manager/dashboard')
    }
  }
  
  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 text-center">Create Manager Account</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name" className="form-label">Full Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={name}
            onChange={handleChange}
            className="form-input"
            placeholder="John Doe"
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="email" className="form-label">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            value={email}
            onChange={handleChange}
            className="form-input"
            placeholder="your@email.com"
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="department" className="form-label">Department</label>
          <input
            type="text"
            id="department"
            name="department"
            value={department}
            onChange={handleChange}
            className="form-input"
            placeholder="Support"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="position" className="form-label">Position</label>
          <input
            type="text"
            id="position"
            name="position"
            value={position}
            onChange={handleChange}
            className="form-input"
            placeholder="Team Lead"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="password" className="form-label">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={password}
            onChange={handleChange}
            className="form-input"
            placeholder="••••••••"
            required
            minLength="6"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="passwordConfirm" className="form-label">Confirm Password</label>
          <input
            type="password"
            id="passwordConfirm"
            name="passwordConfirm"
            value={passwordConfirm}
            onChange={handleChange}
            className="form-input"
            placeholder="••••••••"
            required
            minLength="6"
          />
        </div>
        
        <button 
          type="submit" 
          className="btn btn-primary w-full"
          disabled={loading}
        >
          {loading ? 'Creating Account...' : 'Register'}
        </button>
      </form>
      
      <div className="mt-6 text-center">
        <p className="text-sm text-[var(--text-secondary)]">
          Already have an account?{' '}
          <Link to="/manager/login" className="text-[var(--primary)] hover:underline">
            Login
          </Link>
        </p>
      </div>
    </div>
  )
}

export default ManagerRegister
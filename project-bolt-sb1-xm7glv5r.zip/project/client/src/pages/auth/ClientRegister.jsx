import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

const ClientRegister = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    passwordConfirm: '',
    phone: '',
    company: ''
  })
  const { registerClientUser, loading } = useAuth()
  const navigate = useNavigate()
  
  const { name, email, password, passwordConfirm, phone, company } = formData
  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (password !== passwordConfirm) {
      alert('Passwords do not match')
      return
    }
    
    // Remove passwordConfirm before sending to API
    const registerData = { ...formData }
    delete registerData.passwordConfirm
    
    const success = await registerClientUser(registerData)
    if (success) {
      navigate('/client/dashboard')
    }
  }
  
  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 text-center">Create Client Account</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name" className="form-label">Full Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={name}
            onChange={handleChange}
            className="form-input"
            placeholder="John Doe"
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="email" className="form-label">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            value={email}
            onChange={handleChange}
            className="form-input"
            placeholder="your@email.com"
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="phone" className="form-label">Phone Number</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={phone}
            onChange={handleChange}
            className="form-input"
            placeholder="+1 (123) 456-7890"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="company" className="form-label">Company (Optional)</label>
          <input
            type="text"
            id="company"
            name="company"
            value={company}
            onChange={handleChange}
            className="form-input"
            placeholder="Your Company Name"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="password" className="form-label">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={password}
            onChange={handleChange}
            className="form-input"
            placeholder="••••••••"
            required
            minLength="6"
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="passwordConfirm" className="form-label">Confirm Password</label>
          <input
            type="password"
            id="passwordConfirm"
            name="passwordConfirm"
            value={passwordConfirm}
            onChange={handleChange}
            className="form-input"
            placeholder="••••••••"
            required
            minLength="6"
          />
        </div>
        
        <button 
          type="submit" 
          className="btn btn-primary w-full"
          disabled={loading}
        >
          {loading ? 'Creating Account...' : 'Register'}
        </button>
      </form>
      
      <div className="mt-6 text-center">
        <p className="text-sm text-[var(--text-secondary)]">
          Already have an account?{' '}
          <Link to="/client/login" className="text-[var(--primary)] hover:underline">
            Login
          </Link>
        </p>
      </div>
    </div>
  )
}

export default ClientRegister
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

const ClientLogin = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  })
  const { loginClientUser, loading } = useAuth()
  const navigate = useNavigate()
  
  const { email, password } = formData
  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    const success = await loginClientUser(formData)
    if (success) {
      navigate('/client/dashboard')
    }
  }
  
  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 text-center">Client Login</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="email" className="form-label">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            value={email}
            onChange={handleChange}
            className="form-input"
            placeholder="your@email.com"
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="password" className="form-label">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={password}
            onChange={handleChange}
            className="form-input"
            placeholder="••••••••"
            required
          />
        </div>
        
        <div className="text-right mb-4">
          <Link to="/forgot-password" className="text-sm text-[var(--primary)] hover:underline">
            Forgot Password?
          </Link>
        </div>
        
        <button 
          type="submit" 
          className="btn btn-primary w-full"
          disabled={loading}
        >
          {loading ? 'Logging in...' : 'Login'}
        </button>
      </form>
      
      <div className="mt-6 text-center">
        <p className="text-sm text-[var(--text-secondary)]">
          Don't have an account?{' '}
          <Link to="/client/register" className="text-[var(--primary)] hover:underline">
            Register
          </Link>
        </p>
      </div>
    </div>
  )
}

export default ClientLogin
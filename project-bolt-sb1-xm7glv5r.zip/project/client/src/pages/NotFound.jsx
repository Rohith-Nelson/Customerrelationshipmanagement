import { Link } from 'react-router-dom'

const NotFound = () => {
  return (
    <div className="page-transition min-h-[80vh] flex flex-col items-center justify-center p-4">
      <h1 className="text-6xl font-bold text-[var(--primary)] mb-2">404</h1>
      <h2 className="text-2xl font-semibold mb-4">Page Not Found</h2>
      <p className="text-[var(--text-secondary)] mb-8 text-center max-w-md">
        The page you're looking for doesn't exist or has been moved.
      </p>
      <Link to="/" className="btn btn-primary">
        Return to Home
      </Link>
    </div>
  )
}

export default NotFound
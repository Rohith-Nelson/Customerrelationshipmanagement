import { useState, useEffect } from 'react'
import { toast } from 'react-toastify'
import { getClientTickets } from '../../services/clientService'
import TicketForm from '../../components/tickets/TicketForm'
import TicketTable from '../../components/tickets/TicketTable'
import { FiInfo } from 'react-icons/fi'

const Tickets = () => {
  const [tickets, setTickets] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [selectedTicket, setSelectedTicket] = useState(null)
  
  useEffect(() => {
    fetchTickets()
  }, [])
  
  const fetchTickets = async () => {
    try {
      setLoading(true)
      const data = await getClientTickets()
      setTickets(data.tickets)
    } catch (error) {
      toast.error('Failed to fetch tickets. Please try again.')
    } finally {
      setLoading(false)
    }
  }
  
  const handleTicketCreated = (newTicket) => {
    setTickets([newTicket, ...tickets])
    setShowForm(false)
  }
  
  const handleViewTicket = (ticket) => {
    setSelectedTicket(ticket)
  }
  
  const closeTicketDetail = () => {
    setSelectedTicket(null)
  }
  
  const toggleForm = () => {
    setShowForm(!showForm)
  }
  
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }
  
  return (
    <div className="page-transition">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold mb-2">Support Tickets</h1>
          <p className="text-[var(--text-secondary)]">
            View and manage your support requests.
          </p>
        </div>
        <button className="btn btn-primary" onClick={toggleForm}>
          {showForm ? 'Cancel' : 'New Ticket'}
        </button>
      </div>
      
      {showForm && (
        <TicketForm onTicketCreated={handleTicketCreated} />
      )}
      
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <p>Loading tickets...</p>
        </div>
      ) : (
        <TicketTable 
          tickets={tickets} 
          userRole="client"
          onViewTicket={handleViewTicket}
        />
      )}
      
      {/* Ticket Detail Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-xl font-bold">{selectedTicket.subject}</h2>
                <button 
                  onClick={closeTicketDetail}
                  className="text-[var(--text-secondary)] hover:text-[var(--text)]"
                >
                  &times;
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Status</p>
                  <p className="font-medium capitalize">{selectedTicket.status}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Priority</p>
                  <p className="font-medium capitalize">{selectedTicket.priority}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Created</p>
                  <p className="font-medium">{formatDate(selectedTicket.createdAt)}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-secondary)]">Last Updated</p>
                  <p className="font-medium">{formatDate(selectedTicket.updatedAt)}</p>
                </div>
              </div>
              
              <div className="mb-6">
                <p className="text-sm text-[var(--text-secondary)] mb-1">Description</p>
                <p className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap">{selectedTicket.description}</p>
              </div>
              
              {selectedTicket.notes && (
                <div className="mb-6">
                  <p className="text-sm text-[var(--text-secondary)] mb-1">Notes from Support</p>
                  <p className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap">{selectedTicket.notes}</p>
                </div>
              )}
              
              {selectedTicket.assignedTo && (
                <div className="flex items-center mb-6 p-3 bg-blue-50 rounded-lg">
                  <FiInfo className="text-[var(--primary)] mr-2" />
                  <p className="text-sm">
                    This ticket is being handled by <span className="font-medium">{selectedTicket.assignedTo.name}</span>.
                  </p>
                </div>
              )}
              
              <div className="flex justify-end">
                <button onClick={closeTicketDetail} className="btn btn-outline">
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Tickets
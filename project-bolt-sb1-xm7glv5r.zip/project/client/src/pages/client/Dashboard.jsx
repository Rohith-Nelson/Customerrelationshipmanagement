import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { FiFileText, FiClock, FiCheckCircle, FiAlertCircle } from 'react-icons/fi'
import DashboardCard from '../../components/dashboard/DashboardCard'
import { getClientTickets } from '../../services/clientService'
import { useAuth } from '../../context/AuthContext'

const ClientDashboard = () => {
  const [tickets, setTickets] = useState([])
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()
  
  useEffect(() => {
    const fetchTickets = async () => {
      try {
        const data = await getClientTickets()
        setTickets(data.tickets)
      } catch (error) {
        console.error('Error fetching tickets:', error)
      } finally {
        setLoading(false)
      }
    }
    
    fetchTickets()
  }, [])
  
  // Calculate ticket stats
  const totalTickets = tickets.length
  const openTickets = tickets.filter(ticket => ticket.status === 'open').length
  const inProgressTickets = tickets.filter(ticket => ticket.status === 'in-progress').length
  const resolvedTickets = tickets.filter(ticket => ticket.status === 'closed').length
  
  // Get most recent tickets
  const recentTickets = [...tickets].sort((a, b) => {
    return new Date(b.createdAt) - new Date(a.createdAt)
  }).slice(0, 5)
  
  return (
    <div className="page-transition">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Welcome, {user?.name || 'Client'}</h1>
        <p className="text-[var(--text-secondary)]">
          Here's an overview of your support tickets and interactions.
        </p>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <DashboardCard
          title="Total Tickets"
          value={totalTickets}
          icon={<FiFileText size={24} />}
          subtitle="All time"
        />
        
        <DashboardCard
          title="Open Tickets"
          value={openTickets}
          icon={<FiClock size={24} />}
          subtitle="Awaiting response"
        />
        
        <DashboardCard
          title="In Progress"
          value={inProgressTickets}
          icon={<FiAlertCircle size={24} />}
          subtitle="Being worked on"
        />
        
        <DashboardCard
          title="Resolved"
          value={resolvedTickets}
          icon={<FiCheckCircle size={24} />}
          subtitle="Successfully closed"
        />
      </div>
      
      {/* Recent Tickets */}
      <div className="card mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Recent Tickets</h2>
          <Link to="/client/tickets" className="text-sm text-[var(--primary)] hover:underline">
            View all
          </Link>
        </div>
        
        {loading ? (
          <p className="text-center py-4 text-[var(--text-secondary)]">Loading tickets...</p>
        ) : recentTickets.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-[var(--text-secondary)] mb-4">You haven't submitted any tickets yet.</p>
            <Link to="/client/tickets" className="btn btn-primary">
              Create Your First Ticket
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-[var(--border)]">
              <thead>
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                    Subject
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                    Priority
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-[var(--text-secondary)] uppercase tracking-wider">
                    Created
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-[var(--border)]">
                {recentTickets.map((ticket) => (
                  <tr key={ticket._id} className="hover:bg-gray-50">
                    <td className="px-4 py-4 whitespace-nowrap">
                      <Link to={`/client/tickets/${ticket._id}`} className="text-[var(--primary)] hover:underline">
                        {ticket.subject}
                      </Link>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                        ${ticket.status === 'open' ? 'bg-blue-100 text-blue-800' : 
                          ticket.status === 'in-progress' ? 'bg-yellow-100 text-yellow-800' : 
                          ticket.status === 'closed' ? 'bg-green-100 text-green-800' : 
                          'bg-gray-100 text-gray-800'}`}>
                        {ticket.status === 'in-progress' ? 'In Progress' : 
                          ticket.status.charAt(0).toUpperCase() + ticket.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                        ${ticket.priority === 'low' ? 'bg-gray-100 text-gray-800' : 
                          ticket.priority === 'medium' ? 'bg-blue-100 text-blue-800' : 
                          ticket.priority === 'high' ? 'bg-yellow-100 text-yellow-800' : 
                          ticket.priority === 'urgent' ? 'bg-red-100 text-red-800' : 
                          'bg-gray-100 text-gray-800'}`}>
                        {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)}
                      </span>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-[var(--text-secondary)]">
                      {new Date(ticket.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* Quick Actions */}
      <div className="card">
        <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <Link to="/client/tickets" className="btn btn-primary text-center">
            Submit New Ticket
          </Link>
          <Link to="/client/profile" className="btn btn-outline text-center">
            Update Profile
          </Link>
          <Link to="/client/tickets" className="btn btn-outline text-center">
            View All Tickets
          </Link>
        </div>
      </div>
    </div>
  )
}

export default ClientDashboard
import { useState, useEffect } from 'react'
import { toast } from 'react-toastify'
import { getClientProfile, updateClientProfile } from '../../services/clientService'
import { useAuth } from '../../context/AuthContext'

const Profile = () => {
  const { user, setUser } = useAuth()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    address: {
      street: '',
      city: '',
      state: '',
      zipCode: '',
      country: ''
    }
  })
  
  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const data = await getClientProfile()
        setProfile(data.client)
      } catch (error) {
        toast.error('Failed to fetch profile. Please try again.')
      } finally {
        setLoading(false)
      }
    }
    
    fetchProfile()
  }, [])
  
  const handleChange = (e) => {
    const { name, value } = e.target
    
    // Handle nested address fields
    if (name.startsWith('address.')) {
      const addressField = name.split('.')[1]
      setProfile({
        ...profile,
        address: {
          ...profile.address,
          [addressField]: value
        }
      })
    } else {
      setProfile({
        ...profile,
        [name]: value
      })
    }
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    setSaving(true)
    
    try {
      const data = await updateClientProfile(profile)
      toast.success('Profile updated successfully!')
      
      // Update user in auth context if name changed
      if (user && profile.name !== user.name) {
        setUser({
          ...user,
          name: profile.name
        })
      }
    } catch (error) {
      toast.error('Failed to update profile. Please try again.')
    } finally {
      setSaving(false)
    }
  }
  
  if (loading) {
    return (
      <div className="page-transition flex justify-center items-center h-64">
        <p>Loading profile...</p>
      </div>
    )
  }
  
  return (
    <div className="page-transition">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">My Profile</h1>
        <p className="text-[var(--text-secondary)]">
          Manage your personal information and preferences.
        </p>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="card mb-6">
          <h2 className="text-xl font-semibold mb-4">Personal Information</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="form-group">
              <label htmlFor="name" className="form-label">Full Name</label>
              <input
                type="text"
                id="name"
                name="name"
                value={profile.name}
                onChange={handleChange}
                className="form-input"
                required
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="email" className="form-label">Email Address</label>
              <input
                type="email"
                id="email"
                name="email"
                value={profile.email}
                onChange={handleChange}
                className="form-input"
                required
                disabled  // Email cannot be changed
              />
              <small className="text-[var(--text-secondary)]">Email cannot be changed.</small>
            </div>
            
            <div className="form-group">
              <label htmlFor="phone" className="form-label">Phone Number</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={profile.phone}
                onChange={handleChange}
                className="form-input"
                placeholder="+1 (123) 456-7890"
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="company" className="form-label">Company</label>
              <input
                type="text"
                id="company"
                name="company"
                value={profile.company}
                onChange={handleChange}
                className="form-input"
                placeholder="Your Company Name"
              />
            </div>
          </div>
        </div>
        
        <div className="card mb-6">
          <h2 className="text-xl font-semibold mb-4">Address Information</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="form-group md:col-span-2">
              <label htmlFor="address.street" className="form-label">Street Address</label>
              <input
                type="text"
                id="address.street"
                name="address.street"
                value={profile.address?.street || ''}
                onChange={handleChange}
                className="form-input"
                placeholder="123 Main St"
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="address.city" className="form-label">City</label>
              <input
                type="text"
                id="address.city"
                name="address.city"
                value={profile.address?.city || ''}
                onChange={handleChange}
                className="form-input"
                placeholder="San Francisco"
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="address.state" className="form-label">State / Province</label>
              <input
                type="text"
                id="address.state"
                name="address.state"
                value={profile.address?.state || ''}
                onChange={handleChange}
                className="form-input"
                placeholder="California"
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="address.zipCode" className="form-label">Zip / Postal Code</label>
              <input
                type="text"
                id="address.zipCode"
                name="address.zipCode"
                value={profile.address?.zipCode || ''}
                onChange={handleChange}
                className="form-input"
                placeholder="94103"
              />
            </div>
            
            <div className="form-group">
              <label htmlFor="address.country" className="form-label">Country</label>
              <input
                type="text"
                id="address.country"
                name="address.country"
                value={profile.address?.country || ''}
                onChange={handleChange}
                className="form-input"
                placeholder="United States"
              />
            </div>
          </div>
        </div>
        
        <div className="flex justify-end space-x-4">
          <button type="button" className="btn btn-outline" onClick={() => window.history.back()}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </form>
    </div>
  )
}

export default Profile
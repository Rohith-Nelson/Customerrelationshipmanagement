import { Link } from 'react-router-dom'
import { FiUsers, FiMessageSquare, FiBarChart2, FiShield } from 'react-icons/fi'

const Home = () => {
  return (
    <div className="page-transition">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-br from-blue-50 to-white rounded-2xl mb-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-10 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
                Simplify Your Customer Relationships
              </h1>
              <p className="text-lg text-[var(--text-secondary)] mb-8">
                Our CRM system helps you build better relationships with your clients.
                Track interactions, manage support tickets, and deliver exceptional service.
              </p>
              <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
                <Link to="/client/register" className="btn btn-primary text-center">
                  Get Started Free
                </Link>
                <Link to="/manager/register" className="btn btn-outline text-center">
                  Manager Account
                </Link>
              </div>
            </div>
            <div className="md:w-1/2 flex justify-center">
              <img 
                src="https://images.pexels.com/photos/3182812/pexels-photo-3182812.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="CRM Dashboard" 
                className="rounded-lg shadow-md max-w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Powerful CRM Features</h2>
            <p className="text-lg text-[var(--text-secondary)] max-w-2xl mx-auto">
              Our comprehensive CRM solution provides all the tools you need to manage 
              customer relationships effectively.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="card hover-scale">
              <div className="text-[var(--primary)] mb-4 text-3xl">
                <FiUsers />
              </div>
              <h3 className="text-xl font-semibold mb-2">Client Management</h3>
              <p className="text-[var(--text-secondary)]">
                Keep track of all your clients, their information, and interaction history.
              </p>
            </div>
            
            <div className="card hover-scale">
              <div className="text-[var(--primary)] mb-4 text-3xl">
                <FiMessageSquare />
              </div>
              <h3 className="text-xl font-semibold mb-2">Support Tickets</h3>
              <p className="text-[var(--text-secondary)]">
                Manage support requests with priority levels and status tracking.
              </p>
            </div>
            
            <div className="card hover-scale">
              <div className="text-[var(--primary)] mb-4 text-3xl">
                <FiBarChart2 />
              </div>
              <h3 className="text-xl font-semibold mb-2">Reporting</h3>
              <p className="text-[var(--text-secondary)]">
                Get insights into customer interactions and support performance.
              </p>
            </div>
            
            <div className="card hover-scale">
              <div className="text-[var(--primary)] mb-4 text-3xl">
                <FiShield />
              </div>
              <h3 className="text-xl font-semibold mb-2">Secure Access</h3>
              <p className="text-[var(--text-secondary)]">
                Role-based access ensures data security and proper permissions.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Testimonial Section */}
      <section className="py-16 bg-gray-50 rounded-2xl">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Trusted by Businesses</h2>
            <p className="text-lg text-[var(--text-secondary)] max-w-2xl mx-auto">
              See what our customers are saying about our CRM system.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-[var(--primary)] font-bold">
                  JD
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold">John Doe</h4>
                  <p className="text-sm text-[var(--text-secondary)]">CEO, Tech Company</p>
                </div>
              </div>
              <p className="text-[var(--text-secondary)]">
                "This CRM has transformed how we manage our customer relationships. The ticketing system 
                alone has improved our response time by 45%."
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-[var(--primary)] font-bold">
                  JS
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold">Jane Smith</h4>
                  <p className="text-sm text-[var(--text-secondary)]">Support Manager</p>
                </div>
              </div>
              <p className="text-[var(--text-secondary)]">
                "As a support manager, I love how easy it is to track tickets and assign them to my team. 
                The reporting features give me valuable insights."
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-[var(--primary)] font-bold">
                  RJ
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold">Robert Johnson</h4>
                  <p className="text-sm text-[var(--text-secondary)]">Small Business Owner</p>
                </div>
              </div>
              <p className="text-[var(--text-secondary)]">
                "For a small business, this CRM provides everything we need at an affordable price. 
                The interface is intuitive and our team was up and running in minutes."
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-10 text-white text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to transform your customer service?</h2>
            <p className="text-lg opacity-90 mb-8 max-w-2xl mx-auto">
              Join thousands of businesses that use our CRM to deliver exceptional customer experiences.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-3 sm:space-y-0 sm:space-x-4">
              <Link to="/client/register" className="btn bg-white text-blue-600 hover:bg-blue-50 text-center">
                Create Free Account
              </Link>
              <Link to="/client/login" className="btn border border-white bg-transparent hover:bg-blue-700 text-center">
                Login
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home
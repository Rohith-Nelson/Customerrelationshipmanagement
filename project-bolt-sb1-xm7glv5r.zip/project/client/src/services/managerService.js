import api from './api'

// Get all clients
export const getClients = async () => {
  const response = await api.get('/api/manager/clients')
  return response.data
}

// Delete client
export const deleteClient = async (clientId) => {
  const response = await api.delete(`/api/manager/client/${clientId}`)
  return response.data
}

// Get all tickets
export const getTickets = async () => {
  const response = await api.get('/api/manager/tickets')
  return response.data
}

// Update ticket
export const updateTicket = async (ticketId, ticketData) => {
  const response = await api.put(`/api/manager/tickets/${ticketId}`, ticketData)
  return response.data
}
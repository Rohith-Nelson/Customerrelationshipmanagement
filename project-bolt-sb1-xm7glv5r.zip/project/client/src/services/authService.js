import api from './api'

// Client authentication
export const loginClient = async (credentials) => {
  const response = await api.post('/api/auth/client/login', credentials)
  return response.data
}

export const registerClient = async (userData) => {
  const response = await api.post('/api/auth/client/register', userData)
  return response.data
}

// Manager authentication
export const loginManager = async (credentials) => {
  const response = await api.post('/api/auth/manager/login', credentials)
  return response.data
}

export const registerManager = async (userData) => {
  const response = await api.post('/api/auth/manager/register', userData)
  return response.data
}
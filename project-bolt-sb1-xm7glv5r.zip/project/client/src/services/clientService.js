import api from './api'

// Get client profile
export const getClientProfile = async () => {
  const response = await api.get('/api/client/profile')
  return response.data
}

// Update client profile
export const updateClientProfile = async (profileData) => {
  const response = await api.put('/api/client/profile', profileData)
  return response.data
}

// Get client tickets
export const getClientTickets = async () => {
  const response = await api.get('/api/client/tickets')
  return response.data
}

// Create new ticket
export const createTicket = async (ticketData) => {
  const response = await api.post('/api/client/ticket', ticketData)
  return response.data
}
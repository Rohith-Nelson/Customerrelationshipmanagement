import { Outlet, useLocation, useNavigate } from 'react-router-dom'
import { useEffect } from 'react'
import Header from '../components/common/Header'
import Footer from '../components/common/Footer'
import Sidebar from '../components/common/Sidebar'
import { useAuth } from '../context/AuthContext'

const MainLayout = () => {
  const { isAuthenticated, user } = useAuth()
  const location = useLocation()
  const navigate = useNavigate()
  
  useEffect(() => {
    // If authenticated and on root path, redirect to appropriate dashboard
    if (isAuthenticated && location.pathname === '/') {
      if (user.role === 'client') {
        navigate('/client/dashboard')
      } else if (user.role === 'manager') {
        navigate('/manager/dashboard')
      }
    }
  }, [isAuthenticated, user, location, navigate])
  
  // Only show sidebar on authenticated routes
  const showSidebar = isAuthenticated && location.pathname !== '/'
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <div className="flex flex-1">
        {showSidebar && <Sidebar />}
        
        <main className={`flex-1 p-4 sm:p-6 md:p-8 ${showSidebar ? 'ml-0 md:ml-64' : ''}`}>
          <div className="page-transition max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
      
      <Footer />
    </div>
  )
}

export default MainLayout
import { Outlet, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Navigate } from 'react-router-dom'

const AuthLayout = () => {
  const { isAuthenticated, user } = useAuth()
  
  // Redirect if already authenticated
  if (isAuthenticated) {
    if (user.role === 'client') {
      return <Navigate to="/client/dashboard" replace />
    } else if (user.role === 'manager') {
      return <Navigate to="/manager/dashboard" replace />
    }
  }
  
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 to-white">
      <header className="py-4 px-6">
        <div className="container mx-auto">
          <Link to="/" className="text-2xl font-bold text-[var(--primary)]">CRM System</Link>
        </div>
      </header>
      
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="page-transition w-full max-w-md">
          <div className="card border border-[var(--border)]">
            <Outlet />
          </div>
        </div>
      </main>
      
      <footer className="py-4 text-center text-sm text-[var(--text-secondary)]">
        <div className="container mx-auto">
          &copy; {new Date().getFullYear()} CRM System. All rights reserved.
        </div>
      </footer>
    </div>
  )
}

export default AuthLayout
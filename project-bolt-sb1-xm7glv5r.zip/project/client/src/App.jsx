import { Routes, Route, Navigate } from 'react-router-dom'
import { useEffect } from 'react'
import { useAuth } from './context/AuthContext'

// Layouts
import MainLayout from './layouts/MainLayout'
import AuthLayout from './layouts/AuthLayout'

// Pages
import Home from './pages/Home'
import ClientLogin from './pages/auth/ClientLogin'
import ClientRegister from './pages/auth/ClientRegister'
import ManagerLogin from './pages/auth/ManagerLogin'
import ManagerRegister from './pages/auth/ManagerRegister'
import ClientDashboard from './pages/client/Dashboard'
import ClientProfile from './pages/client/Profile'
import ClientTickets from './pages/client/Tickets'
import ManagerDashboard from './pages/manager/Dashboard'
import ManagerClients from './pages/manager/Clients'
import ManagerTickets from './pages/manager/Tickets'
import NotFound from './pages/NotFound'

// Protected Route Component
const ProtectedRoute = ({ children, allowedRole }) => {
  const { user, isAuthenticated } = useAuth()
  
  if (!isAuthenticated) {
    return <Navigate to="/" replace />
  }
  
  if (allowedRole && user.role !== allowedRole) {
    return <Navigate to="/" replace />
  }
  
  return children
}

function App() {
  const { checkAuth } = useAuth()
  
  useEffect(() => {
    checkAuth()
  }, [checkAuth])

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<MainLayout />}>
        <Route index element={<Home />} />
      </Route>
      
      {/* Auth Routes */}
      <Route path="/" element={<AuthLayout />}>
        <Route path="client/login" element={<ClientLogin />} />
        <Route path="client/register" element={<ClientRegister />} />
        <Route path="manager/login" element={<ManagerLogin />} />
        <Route path="manager/register" element={<ManagerRegister />} />
      </Route>
      
      {/* Client Routes */}
      <Route path="/client" element={
        <ProtectedRoute allowedRole="client">
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route path="dashboard" element={<ClientDashboard />} />
        <Route path="profile" element={<ClientProfile />} />
        <Route path="tickets" element={<ClientTickets />} />
      </Route>
      
      {/* Manager Routes */}
      <Route path="/manager" element={
        <ProtectedRoute allowedRole="manager">
          <MainLayout />
        </ProtectedRoute>
      }>
        <Route path="dashboard" element={<ManagerDashboard />} />
        <Route path="clients" element={<ManagerClients />} />
        <Route path="tickets" element={<ManagerTickets />} />
      </Route>
      
      {/* 404 Route */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}

export default App
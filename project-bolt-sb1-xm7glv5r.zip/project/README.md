# CRM System

A full-stack Customer Relationship Management system with separate portals for clients and managers, built with React, Express, and MongoDB.

## Features

- **Authentication System**: Separate login and registration for clients and managers
- **Client Dashboard**: Profile management, ticket submission and tracking
- **Manager Dashboard**: Client management, ticket handling and assignment
- **RESTful API**: Complete backend API with JWT authentication
- **Modern UI**: Clean, responsive design with Tailwind CSS

## Tech Stack

### Frontend
- React (with React Router DOM for routing)
- Tailwind CSS (for styling)
- Axios (for API requests)
- React Icons
- React Toastify (for notifications)

### Backend
- Node.js
- Express
- MongoDB (with Mongoose)
- JWT for authentication
- bcryptjs for password hashing
- CORS support

## Project Structure

```
/
├── client/              # Frontend React application
│   ├── public/
│   └── src/
│       ├── components/  # Reusable UI components
│       ├── context/     # React context for state management
│       ├── pages/       # Page components
│       ├── services/    # API service layer
│       └── utils/       # Utility functions
│
├── server/              # Backend Express application
│   ├── controllers/     # Route controllers
│   ├── middleware/      # Custom middleware
│   ├── models/          # Mongoose models
│   ├── routes/          # API routes
│   └── utils/           # Utility functions
│
└── README.md            # Project documentation
```

## Getting Started

### Prerequisites

- Node.js (v14+ recommended)
- MongoDB (local installation or MongoDB Atlas account)

### Installation

1. Clone the repository
2. Install root dependencies:
   ```
   npm install
   ```

3. Install client and server dependencies:
   ```
   npm run install-all
   ```

4. Set up your environment variables:
   - Create a `.env` file in the server directory based on the provided `.env.example`
   - Update MongoDB connection string and JWT secret

5. Start development servers (both frontend and backend):
   ```
   npm run dev
   ```

## API Endpoints

### Authentication Routes
- POST `/api/auth/client/register` - Register a new client
- POST `/api/auth/client/login` - Login as a client
- POST `/api/auth/manager/register` - Register a new manager
- POST `/api/auth/manager/login` - Login as a manager

### Client Routes (Protected)
- GET `/api/client/profile` - Get client profile
- PUT `/api/client/profile` - Update client profile
- POST `/api/client/ticket` - Create a new support ticket
- GET `/api/client/tickets` - Get all client tickets

### Manager Routes (Protected)
- GET `/api/manager/clients` - Get all clients
- DELETE `/api/manager/client/:id` - Delete a client
- GET `/api/manager/tickets` - Get all tickets
- PUT `/api/manager/tickets/:id` - Update a ticket

## License

This project is licensed under the MIT License - see the LICENSE file for details